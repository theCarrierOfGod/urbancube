# Anta Typeface by Sergej Lebedev
**Anta, a modern font family, is intelligently designed for screen publications. Anta Typeface has several interesting, constructed glyph shapes that give the typeface a modern look. The typeface is particularly suitable for graphic design, but also for branding projects.**

![Anta](documentation/Anta.png)
